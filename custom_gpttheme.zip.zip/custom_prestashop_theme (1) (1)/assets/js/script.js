// Custom JavaScript can be added here
document.addEventListener('DOMContentLoaded', function() {
    console.log('Custom theme script loaded');
});
