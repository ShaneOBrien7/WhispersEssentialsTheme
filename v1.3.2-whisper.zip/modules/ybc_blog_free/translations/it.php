<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>blog_list_59526bf44608558c7a7331e99f4b8038'] = 'Ultimi post';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_16_59526bf44608558c7a7331e99f4b8038'] = 'Ultimi post';
$_MODULE['<{ybc_blog_free}prestashop>gallery_03904e973e81c46dfc62dcc40779d51e'] = 'Galleria di immagini';
$_MODULE['<{ybc_blog_free}prestashop>gallery_16_03904e973e81c46dfc62dcc40779d51e'] = 'Galleria di immagini';
$_MODULE['<{ybc_blog_free}prestashop>single_post_f629bf1c1f0bbf252a04c92ec02cd8ce'] = 'Soggetto';
$_MODULE['<{ybc_blog_free}prestashop>single_post_b3af7359325b2925acbf98a7484158bc'] = 'Commento';
$_MODULE['<{ybc_blog_free}prestashop>single_post_16_b3af7359325b2925acbf98a7484158bc'] = 'Commento';
$_MODULE['<{ybc_blog_free}prestashop>categories_block_3cfd94e5b1e020a2b88c15f49d57886e'] = 'Categorie ';
