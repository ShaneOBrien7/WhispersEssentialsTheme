INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','Shop with love','<p>Get Free Shipping on all orders<br /> over $200 and free returns to our<br /> main returns center!</p>','','Shop now','#','10d93f9357faa21f7b87e83cb38bddcf72262688_home-1-slide-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('3','_ID_LANG_','Summer Trend','<p>From haute sweatshirst to matching separates and<br /> swinging earrings, see the best of what\'s new<br /> in summer style.</p>','','Shop now','#','1d19554110071a88d223eea723dbdeb1faf91e3c_home-1-slide-c.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('10','_ID_LANG_','Season collection','<p>Shop the autumn collection now with our edit of pieces<br /> that were revealed exclusively at our autumn/winter<br /> press show!</p>','','Shop now','#','7d91eddd8bc72d581898ada3271267f47b0fe329_home-1-slide-b.jpg');


