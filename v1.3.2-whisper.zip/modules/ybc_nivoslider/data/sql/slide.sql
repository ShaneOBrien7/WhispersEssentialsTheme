INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('1','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('3','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('10','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('1','0','1','random','10%','10%','10%','type4','left','left','44%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('3','0','1','random','10%','10%','10%','type3','left','left','40%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('10','0','1','random','10%','10%','10%','type2','right','left','40%','','#');


