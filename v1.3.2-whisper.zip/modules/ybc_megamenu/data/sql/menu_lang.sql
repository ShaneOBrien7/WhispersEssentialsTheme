INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('2','_ID_LANG_','Women\'s');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('3','_ID_LANG_','Men\'s');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('4','_ID_LANG_','Accessories');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('5','_ID_LANG_','Contact Us');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('6','_ID_LANG_','Shoes');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('7','_ID_LANG_','Blog');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('12','_ID_LANG_','Home');


INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('1','_ID_LANG_','Diamond Test','','<ul><li><a href=\"#\">Blouses</a></li>
<li><a href=\"#\">Evening Dresses</a></li>
<li><a href=\"#\">T-shirts</a></li>
<li><a href=\"#\">Tops</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('2','_ID_LANG_','Sample links','','<ul><li><a href=\"#\">Blouses</a></li>
<li><a href=\"#\">Evening Dresses</a></li>
<li><a href=\"#\">T-shirts</a></li>
<li><a href=\"#\">Tops</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('3','_ID_LANG_','Sample links','','<ul><li><a href=\"#\">Blouses</a></li>
<li><a href=\"#\">Evening Dresses</a></li>
<li><a href=\"#\">T-shirts</a></li>
<li><a href=\"#\">Tops</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('4','_ID_LANG_','','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('5','_ID_LANG_','Sample links','','<ul><li><a href=\"#\">Blouses</a></li>
<li><a href=\"#\">Evening Dresses</a></li>
<li><a href=\"#\">T-shirts</a></li>
<li><a href=\"#\">Tops</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('6','_ID_LANG_','Sample links','','<ul><li><a href=\"#\">Blouses</a></li>
<li><a href=\"#\">Evening Dresses</a></li>
<li><a href=\"#\">T-shirts</a></li>
<li><a href=\"#\">Tops</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('7','_ID_LANG_','Sample links','','<ul><li><a href=\"#\">Blouses</a></li>
<li><a href=\"#\">Evening Dresses</a></li>
<li><a href=\"#\">T-shirts</a></li>
<li><a href=\"#\">Tops</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('15','_ID_LANG_','Clothing','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('16','_ID_LANG_','Best Sellers','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('17','_ID_LANG_','Full width','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('18','_ID_LANG_','DRESSES','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('19','_ID_LANG_','Shorts','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('20','_ID_LANG_','Teen','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('21','_ID_LANG_','Trousers','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('22','_ID_LANG_','Shoes Adidas','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('23','_ID_LANG_','Full width','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('24','_ID_LANG_','Casual Jean','','');


INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('1','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('2','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('3','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('4','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('10','_ID_LANG_','Column 6/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('11','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('12','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('13','_ID_LANG_','Column 4/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('14','_ID_LANG_','Column 4/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('15','_ID_LANG_','Column 4/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('16','_ID_LANG_','Full width','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('17','_ID_LANG_','Full width','');


