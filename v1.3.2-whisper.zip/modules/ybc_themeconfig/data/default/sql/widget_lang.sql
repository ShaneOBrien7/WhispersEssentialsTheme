INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('1','_ID_LANG_','Payment logos','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('2','_ID_LANG_','banner 1','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('3','_ID_LANG_','banner 2','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('4','_ID_LANG_','banner 3','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('14','_ID_LANG_','banner 1','
                                 <div class=\"block_banner_home\">
                                    <h2>Summer Sale</h2>
                                    <h1>Up tp 60% off</h1>
                                    <p><button>Shop now</button></p>
                                 </div>
                                 ');


