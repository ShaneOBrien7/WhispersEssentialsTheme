INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('7','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('8','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('9','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('7','0','1','random','10%','10%','10%','type1','center','center','40%','','');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('8','0','1','random','10%','10%','10%','type2','center','center','40%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('9','0','1','random','8%','10%','10%','type3','left','left','50%','','#');


