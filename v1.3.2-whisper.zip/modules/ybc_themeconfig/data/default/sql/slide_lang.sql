INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('7','_ID_LANG_','FIND A PERFECT GIFT FOR YOUR GIRL?','<p><span class=\"caption-span\">Special collection for girls</span></p>','','','','05aa064bc564f96a97d54df885f00cccfefae7d0_home-3-slide-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('8','_ID_LANG_','SUMMER SALES','','Women\'s collection','LEARN MORE','','a577b3d115d9e93b9905fdabaa3ec054962c2f01_home-3-slide-b.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('9','_ID_LANG_','7 TYPES OF SANDAlS TO INVEST IN THIS SUMMER','','The only shoes you need this season','LEARN MORE','','059ea443f352d4a51ae50a51df3a43eb72abc8ad_home-3-slide-c.jpg');


