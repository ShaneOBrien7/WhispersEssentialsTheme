INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('4','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('5','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('6','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('4','0','1','random','10%','10%','10%','type1','left','left','40%','','');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('5','0','1','random','10%','10%','10%','type1','left','left','40%','','');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('6','0','1','random','10%','10%','10%','type1','left','left','40%','','');


