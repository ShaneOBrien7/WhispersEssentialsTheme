INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('1','_ID_LANG_','Payment logos','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('10','_ID_LANG_','Bag','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('11','_ID_LANG_','women','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('12','_ID_LANG_','watch','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('13','_ID_LANG_','accessories','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('15','_ID_LANG_','return exchange','
                                    <i class=\"fa fa-repeat\" aria-hidden=\"true\"></i>
                                    <h2>return exchange</h2>
                                    <p>Free return or exchange in 10 days</p>
                                 ');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('16','_ID_LANG_','Free shipping','
                                    <i class=\"fa fa-plane\" aria-hidden=\"true\"></i>
                                    <h2>Free shipping</h2>
                                    <p>For all order over $150.00</p>
                                 ');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('17','_ID_LANG_','Customer support','
                                    <i class=\"fa fa-phone\" aria-hidden=\"true\"></i>
                                    <h2>Customer support</h2>
                                    <p>Online store 24/7</p>
                                 ');


