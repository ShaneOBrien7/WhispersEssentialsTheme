INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('1','ybcPaymentLogo','1','0','1','1','paymentlogos.png','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('10','displaytopcolumn','1','0','1','1','top-9.jpg','','#','10');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('11','displaytopcolumn','1','0','1','1','top-10.jpg','','#','11');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('12','displaytopcolumn','1','0','1','1','top-11.jpg','','#','12');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('13','displaytopcolumn','1','0','1','1','top-12.jpg','','#','13');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('15','ybccustom2','1','0','1','1','','','#','15');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('16','ybccustom2','1','0','1','1','','','#','16');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('17','ybccustom2','1','0','1','1','','','#','17');


