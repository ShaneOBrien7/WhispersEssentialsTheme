INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('4','_ID_LANG_','','','','','','79583ac373b83ae32d7d9b50f959b86df9d5f032_home-2-slide-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('5','_ID_LANG_','','','','','','ca0ca4e8050a96f8aa97f0e3a7664927f0f2fbd8_home-2-slide-b.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('6','_ID_LANG_','','','','','','95293358a42da07085fd74243aed899cb84f367b_home-2-slide-c.jpg');


