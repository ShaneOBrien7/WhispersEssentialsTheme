INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('1','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('5','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('6','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('1','0','1','random','15%','7%','10%','type1','left','center','49%','c1_cl_red','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('5','1','1','random','16%','10%','10%','type2','right','center','50%','c1_cl_red','');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('6','6','1','random','13%','10%','10%','type3','right','center','60%','c1_cl_red c2_cl_w','#');


