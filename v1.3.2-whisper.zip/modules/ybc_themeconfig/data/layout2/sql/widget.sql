INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('1','ybcPaymentLogo','1','0','1','1','paymentlogos.png','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('5','displaytopcolumn','1','1','1','1','top-4.jpg','','#','5');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('6','displaytopcolumn','1','1','1','1','top-5.jpg','','#','6');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('7','displaytopcolumn','1','1','1','1','top-6.jpg','','#','7');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('8','displaytopcolumn','1','1','1','1','top-7.jpg','','#','8');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('9','displaytopcolumn','1','1','1','1','top-8.jpg','','#','9');


