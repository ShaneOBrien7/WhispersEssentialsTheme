INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('1','_ID_LANG_','Payment logos','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('5','_ID_LANG_','footwear','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('6','_ID_LANG_','hand bag','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('7','_ID_LANG_','Women\'s','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('8','_ID_LANG_','watch','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('9','_ID_LANG_','women belt','');


