INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('13','_ID_LANG_','Women\'s jewelry','<p><a href=\"#\" class=\"button\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('27','_ID_LANG_','Luxury jewelry','<p><a href=\"#\" class=\"button\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('28','_ID_LANG_','necklace','<p><a href=\"#\" class=\"button\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('29','_ID_LANG_','earrings','<p><a href=\"#\" class=\"button\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('30','_ID_LANG_','wedding necklace','<p><a href=\"#\" class=\"button\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('33','_ID_LANG_','New arrivals','<p><a href=\"#\" class=\"button\">Purchase now</a></p>');


